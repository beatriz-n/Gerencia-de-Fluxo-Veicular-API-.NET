﻿
namespace FluxoVeicular.ServiceDefaults.Entities
{
    public class Veiculo
    {
        public Guid Id { get; set; }
        public string? Placa { get; set; }
        public string? Cor { get; set; }
    }
}
